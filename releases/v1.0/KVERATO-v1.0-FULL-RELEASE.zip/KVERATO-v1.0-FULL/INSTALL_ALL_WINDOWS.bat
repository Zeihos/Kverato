@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto :failed
if not exist "VK\install_vk_windows.bat" goto :missing
if not exist "Telegram\install_tg_windows.bat" goto :missing
if not exist "Discord\install_discord_windows.bat" goto :missing
echo [KVERATO] Installing VK...
call "%~dp0VK\install_vk_windows.bat"
if errorlevel 1 goto :failed
echo [KVERATO] Installing Telegram...
call "%~dp0Telegram\install_tg_windows.bat"
if errorlevel 1 goto :failed
echo [KVERATO] Installing Discord...
call "%~dp0Discord\install_discord_windows.bat"
if errorlevel 1 goto :failed
echo [OK] All dependencies installed.
echo [INFO] Configure .env in each of the VK, Telegram and Discord folders.
pause
exit /b 0
:missing
echo [ERROR] A platform installation script is missing.
goto :failed
:failed
echo [ERROR] Installation did not complete; check the message above.
pause
exit /b 1

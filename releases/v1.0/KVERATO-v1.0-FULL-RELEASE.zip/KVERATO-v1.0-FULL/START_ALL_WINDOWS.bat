@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if errorlevel 1 goto :failed
if not exist "VK\.env" goto :missing_vk
if not exist "Telegram\.env" goto :missing_tg
if not exist "Discord\.env" goto :missing_discord
if not exist "VK\start_vk.bat" goto :failed
if not exist "Telegram\start_tg.bat" goto :failed
if not exist "Discord\start_discord.bat" goto :failed
start "KVERATO VK" /D "%~dp0VK" "%ComSpec%" /c "call start_vk.bat"
start "KVERATO Telegram" /D "%~dp0Telegram" "%ComSpec%" /c "call start_tg.bat"
start "KVERATO Discord" /D "%~dp0Discord" "%ComSpec%" /c "call start_discord.bat"
echo [KVERATO] Started VK, Telegram and Discord in separate windows.
exit /b 0
:missing_vk
echo [ERROR] Configure VK\.env before starting.
goto :failed
:missing_tg
echo [ERROR] Configure Telegram\.env before starting.
goto :failed
:missing_discord
echo [ERROR] Configure Discord\.env before starting.
goto :failed
:failed
pause
exit /b 1
